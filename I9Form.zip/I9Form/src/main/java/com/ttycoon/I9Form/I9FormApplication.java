package com.ttycoon.I9Form;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class I9FormApplication {

	public static void main(String[] args) {
		SpringApplication.run(I9FormApplication.class, args);
	}

}
