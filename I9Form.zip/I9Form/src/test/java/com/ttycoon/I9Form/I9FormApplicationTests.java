package com.ttycoon.I9Form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I9FormApplicationTests {

	@Test
	void contextLoads() {
	}

}
